package com.msp.hyunjihyerim.termproject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by hyun ji Ra on 2016-06-12.
 */
public class AlarmService extends Service {
    private static final String TAG = "AlertService";
    final static String Entering_ACTION = "Entering_ACTION";
    final static String Alarm_ACTION = "Alarm_ACTION";
    final static String Data_ACTION = "Data_ACTION";

    AlarmManager am;
    PendingIntent pendingIntent;
    private CountDownTimer timer;
    StepMonitor accelMonitor;
    LocationMonitor locationMonitor;
    int sleepingTime, beforeTime;

    List<ScanResult> scanList;

    WifiManager wifiManager;
    ArrayList<WifiList> wifiList = new ArrayList<WifiList>();

    String topPlace = " ";
    int topTime = 0;

    long start, end;
    int time;
    int isIn = -1;
    int outCheck = 0;
    String resultString;
    Intent i;

    int duringTime; // 정지 또는 이동 시간
    int movingTime = 0;
    boolean isMoving; // 이동 중인가 정지 했는가
    long now; // 최근 시간
    long prior; // 측정시작시간
    long now2; // 최근 시간
    long prior2; // 측정시작시간
    String priorString, nowString;
    String priorString2, nowString2;
    boolean final_isMoved;
    String sectionTime;

    String lastLocation;
    String resultData;
    String isEnter;
    boolean isResistLocation, iswifi;
    String nowLocation;

    Boolean isEntering;
    String gpsLocation;
    int isInGps = -1;

    String message, temp;
    double final_steps, cur_steps,betweenSteps, totalSteps;

    // Alarm 시간이 되었을 때 안드로이드 시스템이 전송해주는 broadcast를 받을 receiver 정의
    // 그리고 다시 동일 시간 후 alarm이 발생하도록 설정한다.

    StepReceiver stepReceiver;

    public class StepReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context arg0, Intent arg1) {
            boolean change = false;
            // TODO Auto-generated method stub
            cur_steps = arg1.getIntExtra("steps", 0);

            isEnter = arg1.getStringExtra("IsEnter");

            Log.e(TAG, "cursteps : " + cur_steps);
            if (cur_steps >= 5) {
                if(isMoving == true){
                    isMoving = true; //계속 이동중이였다!
                    final_steps += cur_steps;
                    //betweenSteps =  final_steps;
                }
                else {
                    isMoving = true; // 그전까지만에도 정지했다가 움직인거다!
                    now = System.currentTimeMillis();
                    Date date = new Date(now);

                    SimpleDateFormat CurTimeFormat = new SimpleDateFormat("HH:mm");
                    nowString = CurTimeFormat.format(date);

                    sectionTime = priorString +"~" +nowString;
                    duringTime=  (int) ((now-prior)/(1000.0*60));

                    final_steps += cur_steps;
                    betweenSteps = final_steps;
                    totalSteps += betweenSteps;
                    if(duringTime >= 5) {
                        change = true;
                        i.putExtra("insideChange", change);
                        resultData = sectionTime + "    " + duringTime + "분    " + "정지  " + isEnter;
                        i.putExtra("resultData", resultData);
                        i.putExtra("steps", (int) totalSteps);
                    }

                    prior = System.currentTimeMillis();

                    Date date2 = new Date(prior);

                    SimpleDateFormat CurTimeFormat2 = new SimpleDateFormat("HH:mm");
                    priorString = CurTimeFormat2.format(date2);

                    if(duringTime >= 5) {
                        Log.e(TAG, "WriteToFile");
                        WriteToFile("\n" + resultData);
                        sendBroadcast(i);
                    }

                }
            }
            else {
                if(isMoving == false) { // 계속 정지해있는다
                    isMoving = false;

                }
                else{
                    isMoving = false; // 이동중이였다가 정지했다!

                    now = System.currentTimeMillis();
                    Date date = new Date(now);

                    SimpleDateFormat CurTimeFormat = new SimpleDateFormat("HH:mm");
                    nowString = CurTimeFormat.format(date);
                    final_isMoved = true; // 이동
                    sectionTime = priorString +"~" +nowString;
                    duringTime=  (int) ((now-prior)/(1000.0*60));
                    movingTime += duringTime;

                    if(duringTime >= 1) {
                        change = false;
                        i.putExtra("movingTime", movingTime);
                        i.putExtra("insideChange", change);
                        resultData = sectionTime + "    " + duringTime + "분    " + "이동" + "    " + (int) betweenSteps + "걸음" + isEnter;
                        i.putExtra("resultData", resultData);
                        i.putExtra("steps", (int) totalSteps);
                    }
                    prior = System.currentTimeMillis();

                    Date date2 = new Date(prior);

                    SimpleDateFormat CurTimeFormat2 = new SimpleDateFormat("HH:mm");
                    priorString = CurTimeFormat2.format(date2);
                    if(duringTime >= 1) {
                        Log.e(TAG, "WriteToFile");
                        WriteToFile("\n" + resultData);
                        sendBroadcast(i);
                    }
                }

            }


        }
    }

    private BroadcastReceiver WifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, Intent intent) {
            if (intent.getAction().equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
                checkProximity();
            }
        }
    };

    private BroadcastReceiver AlarmReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, Intent intent) {

            if (intent.getAction().equals(Entering_ACTION)) {
                isEntering = intent.getBooleanExtra("IsEntering", false);
                gpsLocation = intent.getStringExtra("IsEnterLocation");
                checkGpsLocation();

                now2 = System.currentTimeMillis();

                Date date2 = new Date(now2);


                SimpleDateFormat CurTimeFormat2 = new SimpleDateFormat("HH:mm");
                nowString2 = CurTimeFormat2.format(now2);
                sectionTime = priorString2 +"~" +nowString2;
                duringTime=  (int) ((now2-prior2)/(1000.0*60));

                isEnter = intent.getStringExtra("isEnter");

            }
            if (intent.getAction().equals(Alarm_ACTION)) {

                accelMonitor = new StepMonitor(context);
                locationMonitor = new LocationMonitor(context);

                Log.e(TAG, "accelMonitor.onStart");
                //Toast.makeText(context, "start", Toast.LENGTH_SHORT).show();
                accelMonitor.onStart();

                wifiManager.startScan();
                iswifi = true;

                //걷고있는 중이라면 location모니터링 시작
                if (isMoving && isResistLocation == false) {
                    locationMonitor.onStart();
                    isResistLocation = true;
                }
                long time = 10000; //10초 동안 스텝감지
                timer = new CountDownTimer(time, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        Log.e(TAG, "accelMonitor.onStop");
                        // Toast.makeText(context, "stop", Toast.LENGTH_SHORT).show();

                        accelMonitor.onStop();

                        if (isResistLocation) {
                            locationMonitor.onStop();
                            isResistLocation = false;
                        }
                        accelMonitor = null;
                        locationMonitor = null;
                        // 다음 alarm 등록
                        Intent in = new Intent(Alarm_ACTION);

                        getSleepingTime(cur_steps);
                        pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, in, 0);
                        am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                                SystemClock.elapsedRealtime() + sleepingTime, pendingIntent);
                    }
                };
                timer.start();


                // 타이머(10초)동안 세었던 걸음 수가 5 이상일 경우 걸었다고 판단하여 메인으로 값을 보내고 메인에서 출력한다.

            }
        }
    };

    private void checkProximity() { //wifi scan
        scanList = wifiManager.getScanResults();
        nowLocation = wifiList.get(20).getName();
        boolean isProximate = false;
        // 등록된 top1 AP가 스캔 결과에 있으며, 그 RSSI가 top1 rssi 값보다 10이하로 작을 때
        // 등록된 장소 근처에 있는 것으로 판단
        // RSSI 크기가 가장 큰 것의 BSSID를 얻음
        int cnt = 0;
        for(int i = 1; i < scanList.size(); i++) {
            ScanResult result = scanList.get(i);
            for(int j = 0; j < wifiList.size(); j++){
                if( (result.BSSID.equals(wifiList.get(j).getBssid())) && (result.level > (wifiList.get(j).getRssi() - 10)) ) {
                    isProximate = true;
                    cnt++;
                    nowLocation = wifiList.get(j).getName();
                }else {
                    isProximate = false;
                }
            }
            isProximate = (cnt >=  4) ? true : false;
        }

        if(isProximate) {
            if(isIn == -1){
                start = System.currentTimeMillis();
                isIn = 1;
                outCheck = 0;
            }
            Toast.makeText(this, "접근중 : " + nowLocation, Toast.LENGTH_SHORT).show();
            Log.d(TAG, "접근중 : " + nowLocation );
        } else {
            if(outCheck > 0 &&isIn == 1){
                end = System.currentTimeMillis();
                isIn = 0;
            }
            outCheck++;
            Log.d(TAG, "접근아님 : " + nowLocation);
        }


        if(isIn == 0) {
            time = (int) ((end-start)/(1000.0*60));
            if(time > 0) {
                resultString = nowLocation;
                Toast.makeText(this, "시간 : " + resultString, Toast.LENGTH_SHORT).show();
                if(time >= topTime)
                topPlace = nowLocation;
                //초기화
                start = 0;
                end = 0;
                isIn = -1;
                outCheck = 0;
                if(time >= 5) {
                    i.putExtra("inside", resultString);
                    i.putExtra("topPlace", topPlace);

                    sendBroadcast(i);
                    WriteToFile("  " + resultString);
                }
            }
        }
    }

    private void checkGpsLocation(){
        if(isEntering){
            if(isInGps == -1){
                start = System.currentTimeMillis();
                isInGps = 1;
            }
            Toast.makeText(this, gpsLocation + " 범위", Toast.LENGTH_SHORT).show();
        }else{
            if(isInGps == 1){
                end = System.currentTimeMillis();
                isInGps = 0;
            }
        }

        if(isInGps == 0){
            time = (int) ((end-start)/(1000.0*60));
            if(time > 0) {
                if(time >= topTime)
                    topPlace = gpsLocation;
                //초기화
                start = 0;
                end = 0;
                isIn = -1;
                //if(time >= 5) {
                    i.putExtra("inside", gpsLocation);
                    i.putExtra("topPlace", topPlace);

                    sendBroadcast(i);
                    WriteToFile("  " + resultString);
                //}
            }
        }

    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }



    @Override
    public void onCreate() {

        stepReceiver = new StepReceiver();


// 현재 시간을 msec으로 구한다.
        prior = System.currentTimeMillis();

        Date date = new Date(prior);


        SimpleDateFormat CurTimeFormat = new SimpleDateFormat("HH:mm");
        priorString = CurTimeFormat.format(date);
        wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        init();

        //초기화
        isEnter = "";
        isEntering = false;
        isMoving = false;
        isResistLocation = false;
        iswifi = false;
        resultData = "A312";
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(WifiReceiver, filter);

        // Alarm 발생 시 전송되는 broadcast를 수신할 receiver 등록
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Alarm_ACTION);
        registerReceiver(AlarmReceiver, intentFilter);

        IntentFilter intentFilter2 = new IntentFilter();
        intentFilter2.addAction(StepMonitor.Step_ACTION);
        intentFilter2.addAction(LocationMonitor.Step_ACTION);
        registerReceiver(stepReceiver, intentFilter2);


        final_steps = 0;
        sleepingTime = 1000;
        beforeTime = sleepingTime;

        i = new Intent();

        i.setAction(Data_ACTION);

        // AlarmManager 객체 얻기
        am = (AlarmManager) getSystemService(ALARM_SERVICE);
    }

    public void init() {
        wifiList.add(new WifiList("다산로비", "KUTAP","a4:18:75:58:77:df",-65));
        wifiList.add(new WifiList("다산로비", "KUTAP", "20:3a:07:49:5c:ef", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "20:3a:07:49:5c:ee", -66));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "a4:18:75:58:77:de", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "20:3a:07:49:5c:e1", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "a4:18:75:58:77:d1", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "88:75:56:c7:1f:11", -66));
        wifiList.add(new WifiList("다산로비", "KUTAP_N", "20:3a:07:9e:a6:c1", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP", "88:75:56:c7:1f:10", -65));
        wifiList.add(new WifiList("다산로비", "KUTAP", "a4:18:75:58:77:d0", -63));
        wifiList.add(new WifiList("다산로비", "KUTAP", "20:3a:07:9e:a6:c0", -66));
        wifiList.add(new WifiList("다산로비", "KUTAP", "20:3a:07:49:5c:e0", -64));
        wifiList.add(new WifiList("다산로비", "KUTAP", "18:33:9d:c6:6a:f0", -64));

        wifiList.add(new WifiList("A312", "ap1-voice", "00:1d:e5:8d:30:a1", -68));
        wifiList.add(new WifiList("A312", "KUTAP", "50:1c:bf:5b:2c:c0", -65));
        wifiList.add(new WifiList("A312", "NSTL 5GHz", "00:26:66:cc:e3:88", -70));
        wifiList.add(new WifiList("A312", "KUTAP_N", "50:1c:bf:41:cf:21", -49));
        wifiList.add(new WifiList("A312", "NSTL 2.4GHz", "00:26:66:cc:e3:8c", -65));
        wifiList.add(new WifiList("A312", "KUTAP", "50:1c:bf:41:cf:20", -46));
        wifiList.add(new WifiList("A312", "KUTAP_N", "50:1c:bf:5b:2c:c1", -66));
        wifiList.add(new WifiList("A312", "KUTAP", "50:1c:bf:5f:7c:e0", -62));
        wifiList.add(new WifiList("A312", "NETGEAR61", "e4:f4:c6:1c:7b:6f", -69));
        wifiList.add(new WifiList("A312", "NETGEAR61-5G", "e4:f4:c6:1c:7b:6e", -68));
        wifiList.add(new WifiList("A312", "ap1-data", "00:1d:e5:8d:30:a0", -65));
        wifiList.add(new WifiList("A312", "KUTAP_N", "50:1c:bf:5f:7c:e1", -60));
        wifiList.add(new WifiList("A312", "A313-3", "64:e5:99:51:18:60", -61));

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // intent: startService() 호출 시 넘기는 intent 객체
        // flags: service start 요청에 대한 부가 정보. 0, START_FLAG_REDELIVERY, START_FLAG_RETRY
        // startId: start 요청을 나타내는 unique integer id
        // Alarm이 발생할 시간이 되었을 때, 안드로이드 시스템에 전송을 요청할 broadcast를 지정
        Intent in = new Intent(Alarm_ACTION);
        pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, in, 0);

        // Alarm이 발생할 시간 및 alarm 발생시 이용할 pending intent 설정
        // 설정한 시간 (5000-> 5초, 10000->10초) 후 alarm 발생
        am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + sleepingTime, pendingIntent);

        return super.onStartCommand(intent, flags, startId);
    }

    //Sleeping time - 걸음수에 따라 계산
    public void getSleepingTime(double cur_steps) {

        if (cur_steps >= 32) {
            sleepingTime = 3000;
        } else if (cur_steps >= 16 && cur_steps < 32) {
            sleepingTime = 5000;
        } else {
            sleepingTime += 3000;

            if (sleepingTime >= 30000) {
                sleepingTime = 30000;
            }
        }

    }

    public void WriteToFile(String msg) {
        //외부메모리에 파일 생성
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Steprecord.txt");
        Log.e(" WriteToFile", Environment.getExternalStorageDirectory().getAbsolutePath());

        try {
            //파일이 기존에 있다면 그 파일에 그대로 값을 append를 한다(덮어쓰는게 아님)
            FileOutputStream fos = new FileOutputStream(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(fos));


            bufferedWriter.write(msg);
            bufferedWriter.newLine();
            bufferedWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(AlarmReceiver);
        unregisterReceiver(stepReceiver);
    }
}